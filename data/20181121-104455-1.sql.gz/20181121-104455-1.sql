-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : tp_51
-- 
-- Part : #1
-- Date : 2018-11-21 10:44:55
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `auth_admin`
-- -----------------------------
DROP TABLE IF EXISTS `auth_admin`;
CREATE TABLE `auth_admin` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `user` varchar(30) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `addtime` varchar(10) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `pid` smallint(6) NOT NULL COMMENT '父id',
  `level` smallint(255) NOT NULL COMMENT '1管理员2经理3员工',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `auth_admin`
-- -----------------------------
INSERT INTO `auth_admin` VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1524362108', '1', '0', '1');

-- -----------------------------
-- Table structure for `auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `describe` varchar(255) DEFAULT NULL COMMENT '描述',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `auth_group`
-- -----------------------------
INSERT INTO `auth_group` VALUES ('1', '角色1', '角色1，测试\r\n', '1', '1,2,3,4,28,29,30,31,32,33,34,35');

-- -----------------------------
-- Table structure for `auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `auth_group_access`;
CREATE TABLE `auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE `auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `auth_rule`
-- -----------------------------
INSERT INTO `auth_rule` VALUES ('1', '#', '主页', '1', '1', '', '0');
INSERT INTO `auth_rule` VALUES ('2', 'admin/index/index', '首页列表', '1', '1', '', '1');
INSERT INTO `auth_rule` VALUES ('3', 'admin/index/content', '首页内容', '1', '1', '', '2');
INSERT INTO `auth_rule` VALUES ('4', '#', '权限管理', '1', '1', '', '0');
INSERT INTO `auth_rule` VALUES ('5', 'admin/group/index', '角色列表', '1', '1', '', '4');
INSERT INTO `auth_rule` VALUES ('6', 'admin/role/index', '用户列表', '1', '1', '', '4');
INSERT INTO `auth_rule` VALUES ('7', 'admin/rule/indexList', '菜单列表', '1', '1', '', '4');
INSERT INTO `auth_rule` VALUES ('8', 'admin/group/edit', '编辑角色', '1', '1', '', '5');
INSERT INTO `auth_rule` VALUES ('9', 'admin/rule/edit', '编辑菜单', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('10', 'admin/rule/usave', '更新菜单', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('11', 'admin/rule/save', '保存菜单', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('12', 'admin/rule/delete', '删除菜单', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('13', 'admin/rule/checked', '菜单禁用', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('14', 'admin/rule/unchecked', '菜单启用', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('15', 'admin/rule/create', '添加菜单', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('16', 'admin/role/create', '添加用户', '1', '1', '', '6');
INSERT INTO `auth_rule` VALUES ('17', 'admin/role/save', '保存用户', '1', '1', '', '6');
INSERT INTO `auth_rule` VALUES ('18', 'admin/role/edit', '编辑用户', '1', '1', '', '6');
INSERT INTO `auth_rule` VALUES ('19', 'admin/role/update', '更新用户', '1', '1', '', '6');
INSERT INTO `auth_rule` VALUES ('20', 'admin/group/create', '添加角色', '1', '1', '', '5');
INSERT INTO `auth_rule` VALUES ('21', 'admin/group/save', '保存角色', '1', '1', '', '5');
INSERT INTO `auth_rule` VALUES ('22', 'admin/group/update', '更新角色', '1', '1', '', '5');
INSERT INTO `auth_rule` VALUES ('23', 'admin/group/checked', '角色禁用', '1', '1', '', '5');
INSERT INTO `auth_rule` VALUES ('24', 'admin/group/unchecked', '角色启用', '1', '1', '', '5');
INSERT INTO `auth_rule` VALUES ('25', 'admin/rule/index', '分配权限', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('26', 'admin/rule/update', '更新权限', '1', '1', '', '7');
INSERT INTO `auth_rule` VALUES ('27', 'admin/role/delete', '删除用户', '1', '1', '', '6');
INSERT INTO `auth_rule` VALUES ('28', '#', '数据库管理', '1', '1', '', '0');
INSERT INTO `auth_rule` VALUES ('29', 'admin/data/index', '备份数据库', '1', '1', '', '28');
INSERT INTO `auth_rule` VALUES ('30', 'admin/data/optimize', '优化表', '1', '1', '', '29');
INSERT INTO `auth_rule` VALUES ('31', 'admin/data/repair', '修复表', '1', '1', '', '29');
INSERT INTO `auth_rule` VALUES ('32', 'admin/data/export', '立即备份', '1', '1', '', '29');
INSERT INTO `auth_rule` VALUES ('33', 'admin/data/import', '还原数据库', '1', '1', '', '28');
INSERT INTO `auth_rule` VALUES ('34', 'admin/data/revert', '还原', '1', '1', '', '33');
INSERT INTO `auth_rule` VALUES ('35', 'admin/data/delete', '删除备份', '1', '1', '', '33');
INSERT INTO `auth_rule` VALUES ('36', 'admin/group/delete', '删除角色', '1', '1', '', '5');
